package com.example.myplane600



import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.AlertDialog
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Card
import androidx.compose.material.IconButton
import androidx.compose.material.RadioButton
import androidx.compose.material.RadioButtonDefaults
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil.compose.rememberImagePainter
import com.example.myplane600.ui.theme.Myplane600Theme
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.Month
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale


class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            Myplane600Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {


                    NavHost(navController, startDestination = "animatescreen") {
                        composable("animatescreen") {
                            animatescreen(navController)
                        }
                        composable("airlinereservation") {
                            AirlineReservationApp(navController)
                        }
                        composable("bookflight",) {
                            Bookflight(navController)
                        }
                        composable("Searchflightscreen") {
                            Searchflightscreen(navController)
                        }
                        composable("tripsummary") {
                            TripSummary(navController)
                        }
                        composable("bookingdetails") {
                            Bookinginfo(navController)
                        }

                        composable("managebook") {
                            managebook(navController)
                        }
                        composable("checkin") {
                            checkin(navController)
                        }
                        composable("menu"){
                            Menudesign(navController)
                        }
                        composable("planeticket"){
                            PlaneTickerCard(navController)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun animatescreen(navController: NavController) {
    val alpha = animateFloatAsState(targetValue = 1f, animationSpec = tween(durationMillis = 3000))


    LaunchedEffect(Unit) {
        delay(3000) // Wait for 5 seconds
        navController.navigate("airlinereservation")
    }


    Splash(alpha = alpha.value)
}

@Composable
fun Splash(alpha: Float) {
    val context = LocalContext.current
    val imagePainter = rememberImagePainter(
        data = context.resources.getDrawable(R.drawable.nick_morales_bwych78rcpi_unsplash__1_)
    )

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {

        Image(
            painter = imagePainter,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = alpha
        )
    }
}



@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RadioButtonSelectionMenu(
    selectedClass: String,
    onSelectedClassChange: (String) -> Unit,
    showClassSelection: Boolean
) {
    if (showClassSelection) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            androidx.compose.material.Text(
                text = "Select Class:",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            val classes = listOf("Economy", "Premium Economy", "Business", "First Class")

            RadioGroup(selectedClass, onSelectedClassChange) {
                classes.forEach { className ->
                    RadioButtonItem(
                        className = className,
                        isSelected = className == selectedClass,
                        onSelectedClassChange = onSelectedClassChange
                    )
                }
            }
        }
    }
}


@Composable
fun RadioGroup(
    selectedClass: String,
    onSelectedClassChange: (String) -> Unit,
    content: @Composable () -> Unit
) {
    // Composable function to wrap the content with RadioGroup logic
    Column {
        content() // Invoke the content lambda
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RadioButtonItem(
    className: String,
    isSelected: Boolean,
    onSelectedClassChange: (String) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        androidx.compose.material3.RadioButton(
            selected = isSelected,
            onClick = { onSelectedClassChange(className) } // Update selected class directly here
        )

        androidx.compose.material.Text(
            text = className,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

data class Airport(
    val airportId: String,
    val airportName: String,
    val city: String,
    val country: String
)

@Composable
fun CountrySelectionDialog(
    onAirportSelected: (Airport) -> Unit,
    onDismiss: () -> Unit,
    originAirport: Airport?,
    destinationAirport: Airport?
) {
    val airports = listOf(
        Airport("JFK", "John F. Kennedy International Airport", "New York", "USA"),
        Airport("LAX", "Los Angeles International Airport", "Los Angeles", "USA"),
        Airport("ORD", "O'Hare International Airport", "Chicago", "USA"),
        Airport("LHR", "Heathrow Airport", "London", "UK"),
        Airport("MAN", "Manchester Airport", "Manchester", "UK"),
        Airport("BHX", "Birmingham Airport", "Birmingham", "UK"),
        Airport("CDG", "Charles de Gaulle Airport", "Paris", "France"),
        Airport("NCE", "Nice Côte d'Azur Airport", "Nice", "France"),
        Airport("LYS", "Lyon-Saint-Exupéry Airport", "Lyon", "France")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select an Airport") },
        buttons = {
            Box(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    airports.forEach { airport ->
                        AirportItem(
                            airport = airport,
                            onAirportSelected = {
                                onAirportSelected(it)
                                onDismiss()
                            }
                        )
                    }
                }
            }
        }
    )
}

@Composable
fun AirportItem(airport: Airport, onAirportSelected: (Airport) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clickable { onAirportSelected(airport) }
    ) {
        androidx.compose.material3.Text(
            text = "Airport ID: ${airport.airportId}",
            style = MaterialTheme.typography.headlineSmall
        )
        Spacer(modifier = Modifier.height(8.dp))
        androidx.compose.material3.Text(
            text = "Airport Name: ${airport.airportName}",
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(8.dp))
        androidx.compose.material3.Text(
            text = "City: ${airport.city}",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(modifier = Modifier.height(8.dp))
        androidx.compose.material3.Text(
            text = "Country: ${airport.country}",
            style = MaterialTheme.typography.bodySmall
        )
    }

}
@Composable
fun SegmentedButtons(
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        options.forEachIndexed { index, option ->
            if (index > 0) {
                Text(
                    text = "|",
                    style = TextStyle(color = Color.Black),
                    modifier = Modifier.padding(4.dp)
                )
            }
            Button(
                onClick = { onOptionSelected(option) },
                modifier = Modifier
                    .padding(4.dp),
                shape = RoundedCornerShape(16.dp), // Add rounded corners here
                colors = ButtonDefaults.buttonColors(
                    backgroundColor = if (option == selectedOption) Color.Green else Color.Blue
                )
            ) {
                Text(text = option, color = if (option == selectedOption) Color.Black else Color.White)
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Bookflight(navController: NavController) {
    val rememberedDepartureDate = remember { mutableStateOf<LocalDate?>(null) }
    val rememberedReturnDate = remember { mutableStateOf<LocalDate?>(null) }
    val rememberedSelectedDate = remember { mutableStateOf<LocalDate?>(null) }
    var selectedOption by remember { mutableStateOf("Round Trip") }
    var originAirport by remember { mutableStateOf<Airport?>(null) }
    var destinationAirport by remember { mutableStateOf<Airport?>(null) }
    var selectingOrigin by remember { mutableStateOf(true) } // Track whether origin or destination is being selected
    var showCountrySelection by remember { mutableStateOf(false) }
    var isOneWay by remember { mutableStateOf(false) }
    var isMultiCity by remember { mutableStateOf(false) }
    var isRoundTrip by remember { mutableStateOf(false) }
    var isCalendarDialogOpen by remember { mutableStateOf(false) }
    var selectedDepartureDate by remember { mutableStateOf<LocalDate?>(null) }
    var selectedReturnDate by remember { mutableStateOf<LocalDate?>(null) }
    var isClassDialogOpen by remember { mutableStateOf(false) }
    Scaffold(
        topBar = {
            TopAppBar(
                colors = topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                title = {
                    Text(
                        text = "Airline Reservation",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        fontSize = 30.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigate("bookflight") }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.primary,
                content = {
                    Row(
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ClickableIcon(Icons.Default.Person, "Home") {
                            navController.navigate("airlinereservation")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Home, "Manage Booking") {
                            navController.navigate("managebook")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.PlayArrow, "Book Flight") {
                            // Navigate back to the previous destination
                            navController.navigate("bookflight")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Check, "Check In") {
                            navController.navigate("checkin")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Menu, "Profile") {
                            navController.navigate("menu")
                        }
                    }
                }
            )
        }
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(top = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopAppBar(
                title = {
                    Row {
                        SegmentedButtons(


                            options = listOf("Round Trip", "One Way", "Multi City"),
                            selectedOption = selectedOption,
                            onOptionSelected = { option ->
                                selectedOption = option
                                // Handle option selection logic here
                                when (option) {
                                    "Round Trip" -> {
                                        isRoundTrip = true
                                        isOneWay = false
                                        isMultiCity = false
                                    }

                                    "One Way" -> {
                                        isRoundTrip = false
                                        isOneWay = true
                                        isMultiCity = false
                                    }

                                    "Multi City" -> {
                                        isRoundTrip = false
                                        isOneWay = false
                                        isMultiCity = true
                                    }
                                }
                            }
                        )

                    }

                }
            )
            Divider()

            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = {
                        // Show country selection for origin
                        showCountrySelection = true
                        selectingOrigin = true
                    },
                    modifier = Modifier
                        .border(BorderStroke(1.dp, Color.Blue), shape = MaterialTheme.shapes.medium)
                        .padding(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = Color.Blue, // Change button color to blue
                        contentColor = Color.White // Change text color to white
                    )
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        originAirport?.let {
                            Text(
                                "Origin: ${it.airportId}, ${it.airportName}",
                                overflow = TextOverflow.Ellipsis,
                                maxLines = 1, // Limit to one line
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                        } ?: Text(
                            "Origin: Select",
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        // Show country selection for destination
                        showCountrySelection = true
                        selectingOrigin = false
                    },
                    modifier = Modifier
                        .border(BorderStroke(1.dp, Color.Blue), shape = MaterialTheme.shapes.medium)
                        .padding(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = Color.Blue, // Change button color to blue
                        contentColor = Color.White // Change text color to white
                    )
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        destinationAirport?.let {
                            Text(
                                "Destination: ${it.airportId}, ${it.airportName}",
                                overflow = TextOverflow.Ellipsis,
                                maxLines = 1, // Limit to one line
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                        } ?: Text(
                            "Destination: Select",
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (showCountrySelection) {
                    CountrySelectionDialog(
                        onAirportSelected = { airport ->
                            if (selectingOrigin) {
                                originAirport = airport
                            } else {
                                destinationAirport = airport
                            }
                        },
                        onDismiss = { showCountrySelection = false },
                        originAirport = originAirport,
                        destinationAirport = destinationAirport
                    )
                }
            }

            Text("Travel Dates", fontWeight = FontWeight.Bold)


            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { isCalendarDialogOpen = true },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                modifier = Modifier
                    .height(50.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = rememberedDepartureDate.value?.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))
                        ?: "Select Date:",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            if (isRoundTrip) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Departure Date", fontWeight = FontWeight.Bold)

                // Departure Dates logic
                // You can add your logic to handle departure dates here

                Button(
                    onClick = { isCalendarDialogOpen = true },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                    modifier = Modifier
                        .height(50.dp)
                        .fillMaxWidth()
                ) {
                    Text(
                        text = rememberedReturnDate.value?.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))
                            ?: "Select Date",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("Return Date", fontWeight = FontWeight.Bold)

                Button(
                    onClick = { isCalendarDialogOpen = true },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                    modifier = Modifier
                        .height(50.dp)
                        .fillMaxWidth()
                ) {
                    Text(
                        text = rememberedSelectedDate.value?.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))
                            ?: "Select Date:",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            var isPassengerDialogOpen by remember { mutableStateOf(false) }
            var adultsCount by remember { mutableStateOf(1) }
            var childrenCount by remember { mutableStateOf(0) }
            var seniorCitizenCount by remember { mutableStateOf(0) }

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Passenger section
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Passenger", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { isPassengerDialogOpen = true },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                        modifier = Modifier
                            .size(60.dp)
                            .width(80.dp)
                    ) {
                        Text("1", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                // Class section
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Class", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { /* Handle class button click */ },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                        modifier = Modifier
                            .size(60.dp)
                            .width(80.dp)

                    ) {
                        Text("", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Button(
                onClick = { navController.navigate("Searchflightscreen") },
                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp) // Adjusted padding for the button
                    .height(50.dp)

            ) {
                Text("Search Flight", color = Color.White, fontWeight = FontWeight.Bold)
            }





            if (isPassengerDialogOpen) {
                Dialog(
                    onDismissRequest = { isPassengerDialogOpen = false },
                    properties = DialogProperties(
                        dismissOnBackPress = true,
                        dismissOnClickOutside = true
                    )
                ) {
                    // Custom content inside the Dialog
                    Surface(
                        modifier = Modifier.background(Color.White), // Change color here
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Adult")
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { if (adultsCount > 0) adultsCount-- }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Remove")
                                }
                                Text(text = adultsCount.toString())
                                IconButton(onClick = { adultsCount++ }) {
                                    Icon(Icons.Default.Add, contentDescription = "Add")
                                }
                            }

                            Text("Child")
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { if (childrenCount > 0) childrenCount-- }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Remove")
                                }
                                Text(text = childrenCount.toString())
                                IconButton(onClick = { childrenCount++ }) {
                                    Icon(Icons.Default.Add, contentDescription = "Add")
                                }
                            }
                            Text("Senior Citizen")
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { if (seniorCitizenCount > 0) seniorCitizenCount-- }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Remove")
                                }
                                Text(text = seniorCitizenCount.toString())
                                IconButton(onClick = { seniorCitizenCount++ }) {
                                    Icon(Icons.Default.Add, contentDescription = "Add")
                                }
                            }

                            // Save and Cancel buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Button(
                                    onClick = { isPassengerDialogOpen = false },
                                    modifier = Modifier.padding(end = 8.dp)
                                ) {
                                    Text("Save")
                                }
                                Button(
                                    onClick = { isPassengerDialogOpen = false },
                                    modifier = Modifier.padding(start = 8.dp)
                                ) {
                                    Text("Cancel")
                                }
                            }
                        }
                    }
                }
            }




            Spacer(modifier = Modifier.height(16.dp))
            // Display calendar dialog when isCalendarDialogOpen is true
            if (isCalendarDialogOpen) {
                Dialog(onDismissRequest = { isCalendarDialogOpen = false }) {
                    Surface(
                        modifier = Modifier.background(Color.White),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Custom content inside the Dialog
                            Calendar(
                                selectedDate = if (isRoundTrip) selectedReturnDate
                                    ?: LocalDate.now() else selectedDepartureDate
                                    ?: LocalDate.now(),
                                onDateSelected = { date ->
                                    if (isRoundTrip) selectedReturnDate =
                                        date else selectedDepartureDate = date
                                },
                                onDismiss = {
                                    isCalendarDialogOpen = false
                                }
                            )

                            Row(
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Cancel button
                                Button(
                                    onClick = { isCalendarDialogOpen = false },
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                ) {
                                    Text("Cancel")
                                }
                                // OK button
                                Button(
                                    onClick = {
                                        // Handle selected date
                                        isCalendarDialogOpen = false
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                ) {
                                    Text("OK")
                                }
                            }
                        }
                    }
                }
                if (isClassDialogOpen) {
                    AlertDialog(
                        onDismissRequest = { isClassDialogOpen = false },
                        buttons = {
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Button(
                                    onClick = { isClassDialogOpen = false },
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                ) {
                                    Text("Cancel")
                                }
                                Button(
                                    onClick = {
                                        // Handle Done button click
                                        isClassDialogOpen = false
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                ) {
                                    Text("Done")
                                }
                            }
                        },
                        properties = DialogProperties(
                            dismissOnBackPress = true,
                            dismissOnClickOutside = true
                        )
                    )
                }

            }
        }
    }
}









@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Calendar(
    selectedDate: LocalDate,
    onDateSelected: (LocalDate) -> Unit,
    onDismiss: () -> Unit
) {
    val selectedYear = selectedDate.year
    val firstMonth = Month.JANUARY
    val lastMonth = Month.DECEMBER

    val rememberedSelectedDate = remember { mutableStateOf<LocalDate?>(null) }
    val showDialog = remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.verticalScroll(rememberScrollState())
    ) {
        Column {
            for (month in firstMonth.value..lastMonth.value) {
                val currentMonth = YearMonth.of(selectedYear, month)
                val firstOfMonth = currentMonth.atDay(1)
                val startDayOfWeek = firstOfMonth.dayOfWeek.value % 7
                val daysInMonth = currentMonth.lengthOfMonth()

                Text(
                    text = currentMonth.month.name,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp)
                )

                // Weekday headers
                Row(Modifier.fillMaxWidth()) {
                    repeat(7) { index ->
                        Text(
                            text = DayOfWeek.of((index + 1) % 7 + 1).toString().substring(0, 3),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Calendar days
                var dayCounter = 1
                repeat(6) { weekIndex ->
                    Row(Modifier.fillMaxWidth()) {
                        repeat(7) { dayIndex ->
                            val isWithinMonth =
                                dayCounter <= daysInMonth && (weekIndex > 0 || dayIndex >= startDayOfWeek)
                            val day = if (isWithinMonth) dayCounter++ else null
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .background(
                                        color = if (day == selectedDate.dayOfMonth) Color.LightGray else Color.Transparent
                                    )
                                    .clickable {
                                        day?.let {
                                            val selectedDate = currentMonth.atDay(it)
                                            rememberedSelectedDate.value = selectedDate
                                            onDateSelected(selectedDate)
                                            onDismiss() // Dismiss the dialog
                                        }
                                    }
                            ) {
                                day?.let {
                                    Text(
                                        text = it.toString(),
                                        style = MaterialTheme.typography.bodySmall,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.align(Alignment.Center)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AirlineReservationApp(navController: NavHostController) {
    var presses by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                title = {
                    Text(
                        text = "Airline Reservation",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        fontSize = 30.sp
                    )
                }
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ClickableIcon(Icons.Default.Person, "Home") {
                        navController.navigate("airlinereservation")
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    ClickableIcon(Icons.Default.Home, "Manage Booking") {
                        navController.navigate("managebook")
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    ClickableIcon(Icons.Default.PlayArrow, "Book Flight") {
                        // Navigate back to the previous destination
                        navController.navigate("bookflight")
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    ClickableIcon(Icons.Default.Check, "Check In") {
                        navController.navigate("checkin")
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    ClickableIcon(Icons.Default.Menu, "Profile") {
                        navController.navigate("menu")
                    }
                }
            }
        },


        ) { innerPadding ->
        // Content area with background picture
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            // Display the background image
            Image(
                painter = painterResource(id = R.drawable.eibner_saliba_3t9ddy0wqdi_unsplash__1_),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                alignment = Alignment.Center
            )

        }
    }
}

@Composable
fun ClickableIcon(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label)
        Text(text = label, fontSize = 14.sp, color = Color.Black)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Searchflightscreen(navController: NavController) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val dates = generateDateList()

    Scaffold(
        topBar = {
            TopAppBar(
                colors = topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                title = {
                    Text(
                        text = "Search Flight",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        fontSize = 30.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigate("bookflight") }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        }
    ) {innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),

            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(text = "Flight", fontSize = 18.sp)
            }
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(dates) { date ->
                        DateItem(date)
                    }
                }
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(onClick = {}) {
                        Text("Filter")
                    }
                    Button(onClick = {}) {
                        Text("Sort by: Price >")
                    }
                }
            }
            items(3) { index ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable {
                            // Handle click action here
                            keyboardController?.hide()
                            navController.navigate("tripsummary")
                        }
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.screenshot_2024_02_11_141734), // Replace with your image resource
                        contentDescription = null, // Provide a descriptive content description
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(Color.Gray)
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable {
                            // Handle click action here
                            keyboardController?.hide()
                            // You can navigate or perform any other action
                        }
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.screenshot_2024_02_11_141734), // Replace with your image resource
                        contentDescription = null, // Provide a descriptive content description
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(Color.Gray)
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable {
                            // Handle click action here
                            keyboardController?.hide()
                            // You can navigate or perform any other action
                        }
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.screenshot_2024_02_11_141734), // Replace with your image resource
                        contentDescription = null, // Provide a descriptive content description
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(Color.Gray)
                    )
                }
            }
        }
    }
}

@Composable
fun TripSummary(navController: NavController) {
    LazyColumn(
        modifier = Modifier
            .padding(2.dp),
        verticalArrangement = Arrangement.SpaceAround
    ) {
        item {
            androidx.compose.material.Text(text = "Trip Summary",
                fontSize = 24.sp, textAlign = TextAlign.Center)
        }
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.weight(3f)
                ) {

                    androidx.compose.material.Text(text = "Selected Departure Flight")
                }

                androidx.compose.material.Text(text = "Change Flight", color = Color.Blue)
            }
        }
        item {
            Image(
                painter = painterResource(id = R.drawable.screenshot__25_),
                contentDescription = null,
                modifier = Modifier
                    .height(453.dp)
                    .fillMaxWidth()
                    .fillMaxHeight()
            )
        }
        item {
            Button(onClick = {
                navController.navigate("bookingdetails")
            },
                modifier = Modifier
                    .padding(16.dp)
                    .height(56.dp)
                    .widthIn(max = 200.dp))
            {
                androidx.compose.material.Text(text = "Checkout")

            }
        }
    }


}




@Composable
fun DateItem(date: Date) {
    Card(
        modifier = Modifier
            .width(120.dp)
            .height(150.dp)
            .padding(5.dp)
            .background(Color.LightGray)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            androidx.compose.material.Text(
                text = SimpleDateFormat("EEE", Locale.getDefault()).format(date),
                style = androidx.compose.material.MaterialTheme.typography.h5
            )
            Spacer(modifier = Modifier.height(4.dp))
            androidx.compose.material.Text(
                text = SimpleDateFormat("MMM dd", Locale.getDefault()).format(date),
                style = androidx.compose.material.MaterialTheme.typography.h5
            )
        }
    }
}
@Composable
fun generateDateList(): List<Date> {
    val currentDate = java.util.Calendar.getInstance()
    val dates = mutableListOf<Date>()

    for (i in 0 until 10) {
        dates.add(currentDate.time)
        currentDate.add(java.util.Calendar.DAY_OF_MONTH, 1)
    }

    return dates
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun managebook(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                colors = topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                title = {
                    Text(
                        text = "My Trips",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        fontSize = 30.sp,
                        color = Color.Black
                    )
                },
                actions = {
                    IconButton(onClick = { /* Handle Add button click */ }) {
                        Icon(Icons.Default.Add, contentDescription = "Add")
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.primary,
                content = {
                    Row(
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ClickableIcon(Icons.Default.Person, "Home") {
                            navController.navigate("airlinereservation")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Home, "Manage Booking") {
                            navController.navigate("managebook")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.PlayArrow, "Book Flight") {
                            // Navigate back to the previous destination
                            navController.navigate("bookflight")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Check, "Check In") {
                            navController.navigate("checkin")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Menu, "Profile") {
                            navController.navigate("menu")
                        }
                    }
                }
            )
        },
        content = { innerpadding ->
            Column(
                modifier = Modifier
                    .padding(innerpadding)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(16.dp))
                Image(
                    painter = painterResource(id = R.drawable.travel),
                    contentDescription = "",
                    modifier = Modifier.size(200.dp) // Adjust the size as needed
                )
                Text(text = "No Trips Available")
                Text(text = "You can Add the Retrieve the details by")
                Text(text = "Using the Add Icon")
                Spacer(modifier = Modifier.height(50.dp))

                Button(
                    onClick = {navController.navigate("bookflight")  },
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .height(50.dp)
                        .width(200.dp)

                ) {
                    Text("Add Trip", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun checkin(navController: NavController) {
    var selectedOption by remember { mutableStateOf("") }

    var bookingReference by remember { mutableStateOf("") }
    var ticketNumber by remember { mutableStateOf("") }
    var frequentFlyer by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    Scaffold(
        topBar = {
            TopAppBar(
                colors = topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                title = {
                    Text(
                        text = "Check In",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        fontSize = 30.sp,
                        color = Color.Black
                    )
                }

            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.primary,
                content = {
                    Row(
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ClickableIcon(Icons.Default.Person, "Home") {
                            navController.navigate("airlinereservation")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Home, "Manage Booking") {
                            navController.navigate("managebook")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.PlayArrow, "Book Flight") {
                            // Navigate back to the previous destination
                            navController.navigate("bookflight")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Check, "Check In") {
                            navController.navigate("checkin")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Menu, "Profile") {
                            navController.navigate("menu")
                        }
                    }
                }
            )
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Row of buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(0.5.dp),
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { selectedOption = "Booking Reference" },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = if (selectedOption == "Booking Reference") Color.Gray else Color.Blue),
                        modifier = Modifier
                            .height(50.dp)
                            .width(115.dp) // Adjust the width as needed
                    ) {
                        Text("Booking Ref.", fontSize = 12.sp, color = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { selectedOption = "Ticket Number" },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = if (selectedOption == "Ticket Number") Color.Gray else Color.Blue),
                        modifier = Modifier
                            .height(50.dp)
                            .width(115.dp) // Adjust the width as needed
                    ) {
                        Text("Ticket No.", fontSize = 12.sp, color = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { selectedOption = "Frequent Flyer" },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = if (selectedOption == "Frequent Flyer") Color.Gray else Color.Blue),

                        modifier = Modifier
                            .height(50.dp)
                            .width(125.dp) // Adjust the width as needed
                    ) {
                        Text("Frequent Flyer", fontSize = 12.sp, color = Color.White)
                    }
                }

                // Content below buttons based on selected option
                when (selectedOption) {
                    "Booking Reference" -> {
                        Text("Booking reference:")
                        TextField(
                            value = bookingReference,
                            onValueChange = { bookingReference = it },
                            modifier = Modifier.width(300.dp)
                        )
                        Divider()
                        Text("Lastname:")
                        TextField(
                            value = lastName,
                            onValueChange = { lastName = it },
                            modifier = Modifier.width(300.dp)
                        )
                        Divider()
                    }
                    "Ticket Number" -> {
                        Text("Ticket number:")
                        TextField(
                            value = ticketNumber,
                            onValueChange = { ticketNumber = it },
                            modifier = Modifier.width(300.dp)
                        )
                        Divider()
                        Text("Lastname:")
                        TextField(
                            value = lastName,
                            onValueChange = { lastName = it },
                            modifier = Modifier.width(300.dp)
                        )
                        Divider()
                    }
                    "Frequent Flyer" -> {
                        Text("Frequent flyer:")
                        TextField(
                            value = frequentFlyer,
                            onValueChange = { frequentFlyer = it },
                            modifier = Modifier.width(300.dp)
                        )
                        Divider()
                        Text("Lastname:")
                        TextField(
                            value = lastName,
                            onValueChange = { lastName = it },
                            modifier = Modifier.width(300.dp)
                        )
                        Divider()
                    }
                }

                // Check In button
                Spacer(modifier = Modifier.height(180.dp))
                Button(
                    onClick = { /* Handle Check In button click */ },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                    modifier = Modifier
                        .height(50.dp)
                        .width(200.dp) // Adjust the width as needed
                ) {
                    Text("Check In", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    )
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Menudesign(navController: NavController) {

    Scaffold(
        topBar = {
            TopAppBar(
                colors = topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                title = {
                    Text(
                        text = "Airline Reservation",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        fontSize = 30.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigate("bookflight") }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.primary,
                content = {
                    Row(
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ClickableIcon(Icons.Default.Person, "Home") {
                            navController.navigate("airlinereservation")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Home, "Manage Booking") {
                            navController.navigate("managebook")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.PlayArrow, "Book Flight") {
                            // Navigate back to the previous destination
                            navController.navigate("bookflight")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Check, "Check In") {
                            navController.navigate("checkin")
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        ClickableIcon(Icons.Default.Menu, "Profile") {
                            navController.navigate("menu")
                        }
                    }
                }
            )
            },
        content = { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .padding(innerPadding)
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.magazine), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "Promotion",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }

                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.plane_ticket), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "Boarding Pass",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.important_notice), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "Flight Status",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }

                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.unknown), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "Flight Disruption",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.coronavirus), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                        .clip(shape = MaterialTheme.shapes.medium)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "About Covid-19",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }

                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.travel_and_tourism), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                        .clip(shape = MaterialTheme.shapes.medium)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "Travel Extras",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }

                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.magazine), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                        .clip(shape = MaterialTheme.shapes.medium)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "News and Events",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }

                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.calendar__1_), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "Timetable",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.phone), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                        .clip(shape = MaterialTheme.shapes.medium)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "Contact Us",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }

                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.terms_and_conditions), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "Terms and Conditions",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }

                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        androidx.compose.material3.Card(
                            modifier = Modifier
                                .padding(16.dp)
                                .width(130.dp)
                                .height(130.dp)
                                .align(Alignment.CenterVertically),
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = 2.dp
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.settings), // Replace with your image resource ID
                                    contentDescription = null,
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(30.dp)
                                        .clip(shape = MaterialTheme.shapes.medium)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.Text(
                                    text = "Settings",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }
        }
    )
}





@Composable
fun Bookinginfo(navController: NavController) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .fillMaxWidth()
            .padding(top = 20.dp, start = 15.dp, end = 15.dp),
        verticalArrangement = Arrangement.Top
    )

    {
        item {
            Column(
                modifier = Modifier.padding(start = 50.dp)
            ) {

                androidx.compose.material3.Text(
                    text = "Booking Information", fontSize = 24.sp,
                    textAlign = TextAlign.Center, color = Color.DarkGray
                )
            }
            Column(
                modifier = Modifier.padding(top = 30.dp)
            ) {

                androidx.compose.material3.Text(text = "Booking Details")
            }
            Column(
                modifier = Modifier.padding(top = 5.dp)
            ) {
                androidx.compose.material3.Card(
                    modifier = Modifier
                        .padding(2.dp)
                        .height(110.dp)
                        .width(320.dp)
                        .background(Color.Transparent),

                    ) {
                    androidx.compose.material3.Text(
                        text = "Depart",
                        Modifier.padding(top = 5.dp, start = 5.dp)
                    )
                    Row(
                        modifier = Modifier
                            .height(60.dp)
                    ) {

                        Image(
                            painter = painterResource(id = R.drawable.cebu_pacific),
                            contentDescription = "",
                        )

                        androidx.compose.material3.Text(
                            text = "MNL - NRT",
                            Modifier.padding(top = 24.dp),
                            fontSize = 12.sp
                        )
                    }
                    Row(
                    ) {
                        androidx.compose.material3.Text(
                            text = "Sat, 19 Jan| 10:30 - 14:40",
                            fontSize = 12.sp,
                            modifier = Modifier.padding(
                                start = 10.dp
                            )
                        )
                    }

                }

            }
        }
        item {
            Column(
                modifier = Modifier.padding(top = 10.dp)
            ) {

                androidx.compose.material3.Text(text = "Passenger Details")
            }
            Column(
                modifier = Modifier.padding(top = 5.dp)
            ) {
                Row(
                    modifier = Modifier.padding(start = 2.dp)
                ) {

                    androidx.compose.material3.Card(
                        modifier = Modifier
                            .padding(2.dp)
                            .height(50.dp)
                            .width(210.dp)
                            .background(Color.Transparent),

                        ) {

                        Row(
                            modifier = Modifier.padding(5.dp)

                        ) {
                            androidx.compose.material3.Text(
                                text = "Adult 1   Enter your data", fontSize = 13.sp,
                                modifier = Modifier.padding(start = 8.dp, top = 10.dp,)
                            )
                            Icon(
                                Icons.Default.KeyboardArrowRight, contentDescription = "",
                                Modifier
                                    .padding(start = 12.dp, top = 7.dp)
                                    .height(25.dp)
                                    .width(30.dp)
                            )
                        }

                    }
                    androidx.compose.material3.Card(
                        modifier = Modifier
                            .padding(2.dp,)
                            .height(50.dp)
                            .width(100.dp)
                            .background(Color.Transparent),

                        ) {

                        Row(
                            modifier = Modifier.padding(5.dp)

                        ) {
                            androidx.compose.material3.Text(
                                text = "Seat", fontSize = 13.sp,
                                modifier = Modifier.padding(start = 7.dp, top = 10.dp)
                            )

                            Icon(
                                Icons.Default.KeyboardArrowRight, contentDescription = "",
                                modifier = Modifier.padding(start = 23.dp, top = 8.dp)
                            )
                        }

                    }

                }
            }
        }
        item {
            Column(
                modifier = Modifier.padding(top = 10.dp)
            ) {

                androidx.compose.material3.Text(text = "Contact Details")
            }
            Column(
                modifier = Modifier.padding(top = 5.dp)
            ) {

                androidx.compose.material3.Card(
                    modifier = Modifier
                        .padding(2.dp)
                        .height(50.dp)
                        .width(320.dp)
                        .background(Color.Transparent),

                    ) {

                    Row(
                        modifier = Modifier.padding(start = 10.dp)

                    ) {
                        androidx.compose.material3.Text(
                            text = "Enter your data", fontSize = 13.sp,
                            modifier = Modifier.padding(top = 15.dp, start = 4.dp)
                        )
                        Icon(
                            Icons.Default.KeyboardArrowRight, contentDescription = "",
                            Modifier
                                .padding(start = 170.dp, top = 13.dp)
                                .height(25.dp)
                                .width(30.dp)
                        )
                    }
                }
            }
        }
        item {
            Column(
                modifier = Modifier.padding(top = 10.dp)
            ) {

                androidx.compose.material3.Text(text = "Add Ons")
                androidx.compose.material3.Text(
                    text = "MNL - NRT",
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
        }
        item {
            Column(
                modifier = Modifier.padding(top = 4.dp)
            ) {

                androidx.compose.material3.Text(text = "Adult 1")
            }
            androidx.compose.material3.Card(
                modifier = Modifier
                    .padding(2.dp, top = 5.dp)
                    .height(50.dp)
                    .width(320.dp)
                    .background(Color.Transparent),

                ) {

                Row(
                    modifier = Modifier.padding(start = 10.dp)

                ) {
                    androidx.compose.material3.Text(
                        text = "+ Add Extra Baggage", fontSize = 13.sp,
                        modifier = Modifier.padding(top = 15.dp, start = 4.dp)
                    )
                    Icon(
                        Icons.Default.KeyboardArrowDown, contentDescription = "",
                        Modifier
                            .padding(start = 130.dp, top = 13.dp)
                            .height(25.dp)
                            .width(30.dp)
                    )
                }
            }
        }

        item {
            Column(
                modifier = Modifier.padding(top = 9.dp)
            ) {

                androidx.compose.material3.Text(text = "Payment Method")
            }
            androidx.compose.material3.Card(
                modifier = Modifier
                    .padding(2.dp, top = 5.dp)
                    .height(50.dp)
                    .width(320.dp)
                    .background(Color.Transparent),

                ) {

                Row(
                    modifier = Modifier.padding(start = 10.dp)

                ) {
                    androidx.compose.material3.Text(
                        text = "Bank Transfer", fontSize = 13.sp,
                        modifier = Modifier.padding(top = 15.dp, start = 4.dp)
                    )
                    Icon(
                        Icons.Default.KeyboardArrowDown, contentDescription = "",
                        Modifier
                            .padding(start = 175.dp, top = 13.dp)
                            .height(25.dp)
                            .width(30.dp)
                    )
                }
            }
        }
        item {
            Column(
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Row {
                    Icon( painterResource(id = R.drawable.unchecked), contentDescription = "", modifier =
                    Modifier
                        .padding(top = 3.dp, start = 5.dp)
                        .height(20.dp)
                        .width(20.dp)
                    )
                    androidx.compose.material3.Text(
                        text = "I want to receive eTravel's exclusive promotion via newsletter",
                        fontSize = 12.sp, modifier = Modifier.padding(
                            start = 5.dp,
                            top = 4.dp
                        )
                    )
                }

            }
        }
        item {
            Column(
                modifier = Modifier.padding(top = 10.dp)
            ) {

            }
            androidx.compose.material3.Text(
                text = "By clicking the Checkout button, you have agreed to terms and conditions of eTravel",
                fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, start = 10.dp)
            )
        }
        item {
            Column(
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(5.dp)

                ) {
                    androidx.compose.material3.Card(
                        modifier = Modifier
                            .padding(2.dp, top = 5.dp)
                            .height(90.dp)
                            .width(120.dp)
                            .background(Color.Transparent),

                        ) {

                        Row(
                            modifier = Modifier.padding(start = 2.dp)

                        ) {
                            androidx.compose.material3.Text(
                                text = "Total Price", fontSize = 12.sp,
                                modifier = Modifier.padding(top = 15.dp, start = 4.dp)
                            )
                            Icon(
                                Icons.Default.KeyboardArrowUp, contentDescription = "",
                                Modifier
                                    .padding(start = 15.dp, top = 10.dp)
                                    .height(25.dp)
                                    .width(30.dp)
                            )
                        }
                        Column(
                            Modifier.padding(start = 5.dp, end = 5.dp)
                        ) {
                            androidx.compose.material3.Text(
                                text = "Php 15,073",
                                fontSize = 12.sp,
                                color = Color.Black
                            )
                            androidx.compose.material3.Text(
                                text = "1 Pax, include Tax",
                                fontSize = 11.sp
                            )
                        }
                    }
                    Column(
                        modifier = Modifier.padding(start = 60.dp, top = 13.dp)
                    ) {

                        ElevatedButton(
                            onClick = {navController.navigate("planeticket") },
                            modifier = Modifier
                                .padding(5.dp)
                                .height(57.dp)
                                .widthIn(max = 200.dp),
                            shape = RoundedCornerShape(13.dp)
                        ) {
                            androidx.compose.material3.Text(text = "Buy Ticket")

                        }
                    }

                }

            }
        }
    }
}
@Composable
fun PlaneTickerCard(navController: NavController) {
    LazyColumn(
        modifier = Modifier
            .padding(5.dp)
            .fillMaxSize()
            .fillMaxWidth(),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.Top
    ) {
        item {
            androidx.compose.material3.Text(
                text = "Boarding Pass",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 12.dp, start = 12.dp)

            )
        }
        item {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.Start,

                ) {
            }
            Image(
                painter = painterResource(id = R.drawable.screenshot_2024_02_13_163248),
                contentDescription = "", modifier = Modifier
                    .height(600.dp)
                    .width(600.dp)
                    .padding(top = 20.dp)
            )
            ElevatedButton(
                onClick = { },
                modifier = Modifier
                    .height(57.dp)
                    .padding(start = 90.dp)
                    .widthIn(max = 200.dp),
                shape = RoundedCornerShape(13.dp)
            ) {
                androidx.compose.material3.Text(text = "Download Information")
            }
        }
    }

}